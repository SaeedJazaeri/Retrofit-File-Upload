package com.example.geeksretrofit;

public class MyResponse {
    boolean error;
    String message;
}
